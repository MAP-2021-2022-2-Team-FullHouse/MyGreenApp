/*import 'package:flutter/material.dart';

class HomeNavBarItem extends StatelessWidget {
  final Color backgroundColor;
  final String? label;
  final Icon? icon;
  HomeNavBarItem(
      {this.backgroundColor = Colors.lightGreen, this.icon, this.label});

  @override
  Widget build(BuildContext context) {
    return Container(item: BottomNavigationBarItem(
          icon: icon,
          label: label,
          backgroundColor: backgroundColor,
        ),;
    );
  }
}*/
