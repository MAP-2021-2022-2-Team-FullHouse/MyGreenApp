import 'package:flutter/material.dart';

class HomePoints extends StatelessWidget {
  const HomePoints({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
